package labAP4;

import java.io.IOException;
import java.util.ArrayList;

interface UserX{
//    public void make()throws IOException;
//    public static int countd=0;
//    public String getName();
    public void Search()throws IOException;
    public int seeReward()throws IOException;
    public void _helper(Object... values)throws IOException;
    public void printX();

}